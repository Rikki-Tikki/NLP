from time import sleep
import selenium
from parsel import Selector
from selenium import webdriver as wd
import csv
import json
import pandas as pd
import re
import unicodedata


def get_browser():
    chrome_options = wd.ChromeOptions()
    browser = wd.Chrome(options=chrome_options)
    return browser


def sign_in():
    with open('login.json') as f:
        d = json.loads(f.read())
        username = d['username']
        password = d['password']
    browser.get('https://www.linkedin.com/login')
    sleep(1)
    loginName = browser.find_element_by_name("session_key")
    loginName.send_keys(username)
    sleep(1)
    loginPass = browser.find_element_by_name("session_password")
    loginPass.send_keys(password)
    sleep(1)
    log_in_button = browser.find_element_by_xpath('//button[@type="submit"]')
    log_in_button.click()
    sleep(1)


def has_organizations():
    try:
        paths = browser.find_elements_by_xpath(".//h3[@class='pv-accomplishments-block__title']")
        for x in range(len(paths)):
            if 'Organizations' in paths[x].text:
                return True
        return False
    except selenium.common.exceptions.NoSuchElementException:
        return False


def has_experience():
    try:
        browser.find_element_by_xpath(".//section[@class='pv-profile-section experience-section ember-view']")
        return True
    except selenium.common.exceptions.NoSuchElementException:
        return False


def has_education():
    try:
        browser.find_element_by_xpath(".//section[@class='pv-profile-section education-section ember-view']")
        return True
    except selenium.common.exceptions.NoSuchElementException:
        return False


def has_about():
    try:
        browser.find_element_by_xpath("//section[@class='artdeco-container-card pv-profile-section pv-about-section ember-view']")
        return True
    except selenium.common.exceptions.NoSuchElementException:
        return False


def has_experience_desc(path):
    try:
        path.find_element_by_xpath(".//p[@class='pv-entity__description t-14 t-black t-normal ember-view']")
        return True
    except selenium.common.exceptions.NoSuchElementException:
        return False


def has_school_years(path):
    try:
        path.find_element_by_xpath(".//p[@class='pv-entity__dates t-14 t-black--light t-normal']")
        return True
    except selenium.common.exceptions.NoSuchElementException:
        return False


def has_degree(path):
    try:
        path.find_element_by_xpath(".//p[@class='pv-entity__secondary-title pv-entity__degree-name t-14 t-black t-normal']")
        return True
    except selenium.common.exceptions.NoSuchElementException:
        return False


def has_field(path):
    try:
        path.find_element_by_xpath(".//p[@class='pv-entity__secondary-title pv-entity__fos t-14 t-black t-normal']")
        return True
    except selenium.common.exceptions.NoSuchElementException:
        return False


def has_timeline_node(path):
    try:
        path.find_element_by_xpath(".//div/div/span[@class='pv-entity__timeline-node']")
        return True
    except selenium.common.exceptions.NoSuchElementException:
        return False


def has_more():
    inputElements = browser.find_elements_by_xpath("//a[@class='lt-line-clamp__more']")
    for x in range(len(inputElements)):
        try:
            inputElement = inputElements[x]
            inputElement.send_keys("\n")
        except selenium.common.exceptions.ElementNotInteractableException:
            print("Couldn't send keys")


def get_about(sel):
    abouts = sel.xpath("//p[@class='pv-about__summary-text mt4 t-14 ember-view']/span/text()").getall()
    about = []
    for x in range(len(abouts)):
        if "..." not in abouts[x]:
            about.append(abouts[x].strip())
    return about


def get_experience():
    rootpath = "section[@class='pv-profile-section experience-section ember-view']/ul/li"
    expSection = browser.find_elements_by_xpath(f"//{rootpath}")
    items = {}
    for x in range(len(expSection)):
        list = []
        if has_timeline_node(expSection[x]):
            try:
                comp = expSection[x].find_element_by_xpath(".//h3[@class='t-16 t-black t-bold']/span[2]").text
                list.append(comp)
            except Exception:
                list.append('N/A')
                
            timelineSections = expSection[x].find_elements_by_xpath(".//section/ul/li")
            for y in range(len(timelineSections)):
                try:
                    pos = timelineSections[y].find_element_by_xpath(".//div/div/div/div/div/div/h3/span[2]").text
                    list.append(pos)
                except Exception:
                    list.append('N/A')

                try:
                    length = timelineSections[y].find_element_by_xpath(".//div/div/div/div/div/div/div/h4/span[2]").text
                    list.append(length)
                except Exception:
                    list.append('N/A')

                expLength = timelineSections[y].find_elements_by_xpath(".//div/div/div/div/div/div")
                if len(expLength) == 3:
                    desc = timelineSections[y].find_elements_by_xpath(".//div/div/div/div/div/div/p/span")
                    for z in range(len(desc)):
                        if "See less" not in desc[z].text:
                            descItems = desc[z].text.strip().split('\n')
                            for a in range(len(descItems)):
                                if descItems[a]:
                                    list.append(descItems[a])
        else:
            try:
                comp = expSection[x].find_element_by_xpath(
                    ".//p[@class='pv-entity__secondary-title t-14 t-black t-normal']").text
                list.append(comp)
            except Exception:
                list.append('N/A')

            try:
                pos = expSection[x].find_element_by_xpath(".//h3[@class='t-16 t-black t-bold']").text
                list.append(pos)
            except Exception:
                list.append('N/A')

            try:
                length = expSection[x].find_element_by_xpath(".//h4[@class='pv-entity__date-range t-14 t-black--light t-normal']/span[2]").text
                list.append(length)
            except Exception:
                    list.append('N/A')
            if has_experience_desc(expSection[x]):
                desc = expSection[x].find_elements_by_xpath(".//p[@class='pv-entity__description t-14 t-black t-normal ember-view']/span")
                for y in range(len(desc)):
                    if "See less" not in desc[y].text:
                        descItems = desc[y].text.strip().split('\n')
                        for z in range(len(descItems)):
                            if descItems[z]:
                                list.append(descItems[z])
        items[x] = list
    return items


def get_education():
    rootpath = "section[@class='pv-profile-section education-section ember-view']/ul/li"
    eduSection = browser.find_elements_by_xpath(f"//{rootpath}")
    items = {}
    for x in range(len(eduSection)):
        list = []
        school = strip_accents(eduSection[x].find_element_by_xpath(".//h3[@class='pv-entity__school-name t-16 t-black t-bold']").text)
        list.append(school)
        if has_school_years(eduSection[x]):
            years = eduSection[x].find_element_by_xpath(".//p[@class='pv-entity__dates t-14 t-black--light t-normal']/span[2]").text
            list.append(years)
        if has_degree(eduSection[x]):
            degree = eduSection[x].find_element_by_xpath(".//p[@class='pv-entity__secondary-title pv-entity__degree-name t-14 t-black t-normal']/span[2]").text
            list.append(degree)
        if has_field(eduSection[x]):
            field = eduSection[x].find_element_by_xpath(".//p[@class='pv-entity__secondary-title pv-entity__fos t-14 t-black t-normal']/span[2]").text
            list.append(field)
        items[x] = list
    return items


def get_organizations(sel):
    orgsUncleaned = sel.xpath("//section[@class='accordion-panel pv-profile-section pv-accomplishments-block organizations ember-view']/div/div/ul/li/text()").getall()
    orgs = []
    for x in range(len(orgsUncleaned)):
        item = strip_accents(orgsUncleaned[x])
        orgs.append(item)
    return orgs


def get_name():
    try:
        text = browser.find_element_by_xpath(".//li[@class='inline t-24 t-black t-normal break-words']").text
        return text
    except selenium.common.exceptions.NoSuchElementException:
        return 'Name cannot be found'


def get_connections():
    try:
        text = browser.find_element_by_xpath(".//div[@class='flex-1 mr5']/ul[@class='pv-top-card-v3--list pv-top-card-v3--list-bullet mt1']/li[@class='inline-block']/span").text
        return text
    except selenium.common.exceptions.NoSuchElementException:
        return 'Connections cannot be found'


def go_to_url(url):
    browser.get(url)
    sleep(1)
    browser.execute_script("window.scrollTo(0, Math.ceil(document.body.scrollHeight/.5));")
    sleep(1)


def strip_accents(text):
    try:
        text = unicodedata(text, 'utf-8')
    except (TypeError, NameError): # unicode is a default on python 3
        pass
    text = unicodedata.normalize('NFD', text)
    text = text.encode('ascii', 'ignore')
    text = text.decode("utf-8")
    return str(text)


def text_to_id(text):
    text = strip_accents(text.lower())
    text = re.sub('[ ]+', '_', text)
    text = re.sub('[^0-9a-zA-Z_-]', '', text)
    return text


browser = get_browser()


def main():
    sign_in()
    data = pd.read_csv('LinkedInUrls.csv')
    links = data.Url.tolist()
    #links = ['https://www.linkedin.com/in/taiza-troutman-a249a917a/']
    for x in range(len(links)):
        items = []
        profile = links[x]
        go_to_url(profile)
        print(f'Now scraping {profile}')
        has_more()
        sel = Selector(text=browser.page_source)
        name = get_name()
        acceptedName = strip_accents(name)
        fileName = f'ProfileScrapes/{text_to_id(acceptedName)}.csv'
        items.append(['Link', profile])
        items.append(['Name', name])
        items.append(['Connections', get_connections()])
        exp = []
        edu = []
        orgs = []
        about = []

        if has_about():
            about = get_about(sel)
        else:
            about.append('N/A')
        items.append(['About', ''])
        for x in range(len(about)):
            items.append(['', about[x]])

        if has_experience():
            exp = get_experience()
        else:
            exp.append('N/A')
        items.append(['Experience', ''])
        for x in range(len(exp)):
            for y in range(len(exp[x])):
                items.append(['', exp[x][y]])
            items.append(['', ''])

        if has_education():
            edu = get_education()
        else:
            edu.append('N/A')
        items.append(['Education', ''])
        for x in range(len(edu)):
            for y in range(len(edu[x])):
                items.append(['', edu[x][y]])
            items.append(['', ''])

        if has_organizations():
            orgs = get_organizations(sel)
        else:
            orgs.append('N/A')
        items.append(['Organizations', ''])
        for x in range(len(orgs)):
            items.append(['', orgs[x]])

        with open(fileName, "w", newline="", encoding='utf8') as f:
            writer = csv.writer(f)
            writer.writerows(items)
        print(f'Finished writing to {fileName}')


if __name__ == '__main__':
    main()
