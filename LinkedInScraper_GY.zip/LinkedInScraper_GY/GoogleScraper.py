from time import sleep
import requests
import time
import selenium
from parsel import Selector
from selenium import webdriver as wd
from selenium.webdriver.common.keys import Keys
import csv


def more_pages():
    try:
        browser.find_element_by_id('pnnext')
        return True
    except selenium.common.exceptions.NoSuchElementException:
        return False


def go_to_next_page():
    next_ = browser.find_element_by_id('pnnext')
    nextUrl = next_.get_attribute('href')
    print(f'Going to {nextUrl}')
    browser.get(nextUrl)
    time.sleep(1)


def get_browser():
    chrome_options = wd.ChromeOptions()
    browser = wd.Chrome(options=chrome_options)
    return browser


def insert_to_list(item, items):
    if item.startswith('https://www.linkedin.com/in/'):
        if item not in items:
            items.append(item)


browser = get_browser()

def main():
    file = open('LinkedInUrls.csv', "w+")
    file.close()
    fields = ['Url']
    with open(r'LinkedInUrls.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(fields)

    browser.get("https://www.google.com/search?q=site%3Alinkedin.com%2Fin%2F+AND+%22bachelor%27s+degree+Georgia+State+University")
    time.sleep(1)
    while(more_pages()):
        urls = []
        links = browser.find_elements_by_xpath("//div[@class='rc']/div[@class='r']/a[@href]")
        while len(links):
            url = links.pop()
            url = url.get_attribute("href")
            insert_to_list(url, urls)
        for x in range(len(urls)):
            fields = [urls[x]]
            with open(r'LinkedInUrls.csv', 'a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(fields)
        go_to_next_page()


if __name__ == '__main__':
    main()